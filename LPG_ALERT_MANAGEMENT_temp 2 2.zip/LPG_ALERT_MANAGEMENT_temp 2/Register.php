<?php 
session_start();


if(isset($_POST['next'])){
    foreach($_POST as $key => $value){
        $_SESSION['information'][$key] = $value;
    }

    
$keys= array_keys($_SESSION['information']);

if(in_array('next',$keys)){
 unset($_SESSION['information']['next']);
 header("Location: signup_page2.php");
}
}

if(isset($_POST['submit'])){
    foreach($_POST as $key => $value){
        $_SESSION['information'][$key] = $value;
    }

    
    $keys= array_keys($_SESSION['information']);

    if(in_array('submit',$keys)){
         unset($_SESSION['information']['submit']);
         header("Location: controlledUser.php");
    }

?>






<!DOCTYPE html>
<html lang="en">
<head>
	<title>Register</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="header">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/background.png);">
					<span class="login100-form-title-1">
						LPG-ALERT Management Register
					</span>
				</div>

				<form class="login100-form validate-form">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Lastname is required">
						<span class="label-input100">Last Name</span>
						<input class="input100" type="text" name="lastname" placeholder="Enter lastname"value = "<?= isset($_SESSION['infomation']['lastname'])
						? $_SESSION['information']['lastname'] : ''?>">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Lastname is required">
						<span class="label-input100">First Name</span>
						<input class="input100" type="text" name="lastname" placeholder="Enter firstname" value = "<?= isset($_SESSION['infomation']['firstname'])
						? $_SESSION['information']['firstname'] : ''?>">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Mobile Number is required">
						<span class="label-input100">Mobile Number</span>
						<input class="input100" type="number" name="num"  value = "<?= isset($_SESSION['infomation']['mobileNumber'])
						? $_SESSION['information']['mobilenumber'] : ''?>">>
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">Username</span>
						<input class="input100" type="text" name="username" placeholder="Enter username"  value = "<?= isset($_SESSION['infomation']['username'])
						? $_SESSION['information']['username'] : ''?>">>
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="text" name="pass" placeholder="Enter Password">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">Verify Password</span>
						<input class="input100" type="password" name="pass" placeholder="Verify Password"  value = "<?= isset($_SESSION['infomation']['verifypassword'])
						? $_SESSION['information']['verifypassword'] : ''?>">>
						<span class="focus-input100"></span>
					</div>
						<br>
						<br>
						<br>
						<br>

					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Back
						</button>
					
						<button class="login100-form-btn">
							Register
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>
	


</body>
</html>