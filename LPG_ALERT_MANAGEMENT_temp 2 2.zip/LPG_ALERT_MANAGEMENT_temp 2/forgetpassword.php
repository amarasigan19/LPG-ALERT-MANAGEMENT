<?php include('connection.php');?>
<?php include('controlledUser.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Forget Password</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<?php
use PHPMailer\PHPMailer\PHPMailer;


require 'vendor/autoload.php';
include('connection.php');
     if (isset($_POST["email"]) && (!empty($_POST["email"]))) {
        $email = $_POST["email"];
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $email = filter_var($email, FILTER_VALIDATE_EMAIL);
        
        



        if (!$email) {
            header("Location: password_page1.php?error=Invalid email address");
            
        } else {
        $sel_query = "SELECT * FROM `account` WHERE email='" . $email . "'";
        $results = mysqli_query($con, $sel_query);
        $row = mysqli_num_rows($results);
            if ($row == "") {
            header("Location: password_page1.php?error=User Not Found");
            }
            
        }
        

        $output = '';

        $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
        $expDate = date("Y-m-d H:i:s", $expFormat);
        $key = md5(time());
        $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
        $key = $key . $addKey;
        
        $sql =  "UPDATE account SET token='$key',expiretoken='$expDate'  WHERE email = '$email'";
        
        mysqli_query($con,  $sql );
                             
        $output.='<p>Please click on the following link to reset your password.</p>';   
        $output.='<p><a href="http://localhost/lpg_management/password_page2.php?key=' .$key . '&email=' .
        
        $email . '&action=reset" target="_blank">http://localhost/lpg_management/password_page2.php?key=' . $key . '&email=' . $email . '&action=reset</a></p>';
        
        $body = $output;        
        $subject = "LPG ALERT MANAGEMENT Reset Password";
                $email_to = $email;        
        //autoload the PHPMailer


        require("vendor/autoload.php");
        $mail = new PHPMailer(); 
        $mail->IsSMTP();
        $mail->Host = "smtp.gmail.com"; // Enter your host here
        $mail->SMTPAuth = true;
        $mail->Username = "lpgalertmanagement@gmail.com"; // Enter your email here
        $mail->Password = "gebrekfbvmrwcean"; //Enter your passwrod here
        $mail->Port = 587;
        $mail->IsHTML(true);        
        $mail->From = "lpgalertmanagement@gmail.com";       
        $mail->FromName = "LPG ALERT MANAGEMENT";        
        $mail->Subject = $subject;        
        $mail->Body = $body;        
        $mail->AddAddress($email_to);
        
        if (!$mail->Send()) {        
            echo "Mailer Error: " . $mail->ErrorInfo;        
        } else {        
            header("Location: password_page1.php?success=Email already Sent");
        }
        
    }
    


?>
	<div class="header">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/background.png);">
					<span class="login100-form-title-1">
						Forget Password?
					</span>
				</div>

				<form class="login100-form validate-form">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">Username</span>
						<input class="input100" type="text" name="username" placeholder="Enter username">
						<span class="focus-input100"></span>
					</div>


						
					

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Forget Passoword
						</button>
					</div>
					

				</form>
			</div>
		</div>
	</div>
	


</body>
</html>