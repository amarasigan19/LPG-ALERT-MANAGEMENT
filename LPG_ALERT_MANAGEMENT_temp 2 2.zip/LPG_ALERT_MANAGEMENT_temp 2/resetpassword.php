<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sign-ln</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<?php
				if (isset($_GET["key"]) && isset($_GET["email"]) && isset($_GET["action"]) 
				&& ($_GET["action"] == "reset") && !isset($_POST["action"])) {
				  $key = $_GET["key"];
				  $email = $_GET["email"];
				  $curDate = date("Y-m-d H:i:s");
				  $sql = "SELECT * FROM `account` WHERE `token`='$key ' and `email`='$email ';";
			   
				  $result = mysqli_query($con, $sql);
				  $row = mysqli_num_rows($result);
				  if ($row == "") {
					header("Location: password_page1.php?error=Invalid Link");
				  } else {        
					$row = mysqli_fetch_assoc($result);
					$expDate = $row['expiredtoken'];
					if ($expDate >= $curDate) {
			  ?>   
			  <!---->
	<div class="header">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/background.png);">
					<span class="login100-form-title-1">
						Welcome to LPG Alert Report
					</span>

				</div>
				<?php if (isset($_GET['error'])) { ?>
     	        	<p class="error"><?php echo $_GET['error']; ?></p>
            	<?php }?>
				<form class="login100-form validate-form">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="text" name="username" placeholder="Enter Password">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">Confirm Password</span>
						<input class="input100" type="password" name="pass" placeholder="Enter password">
						<span class="focus-input100"></span>
					</div>


					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Reset Password
						</button>
                        
					</div>
					

				</form>
				<?php
			} else {
			  header("Location: password_page1.php?error=Link Expired");

			}
}
	   
}


	if (isset($_POST["email"]) && isset($_POST["action"]) && ($_POST["action"] == "update")) {
	   
		$pass1 = mysqli_real_escape_string($con, $_POST["pass1"]);
		$pass2 = mysqli_real_escape_string($con, $_POST["pass2"]);
		$email = $_POST["email"];
		$curDate = date("Y-m-d H:i:s");
		if ($pass1 != $pass2) {
			header("Location: password_page2.php?error=Password do not match, both password should be same");
		}
	   

			$pass1 = encryption($pass1);
			$query = "UPDATE `account` SET `password` = ' $pass1 ' WHERE `email` = ' $email ";
			$results= mysqli_query($con, $query);

			if(mysqli_num_rows($result) === 1){

			
			  header("Location: login.php?success=Your password has been changed successfully");
			  exit();
	
			}

			
		}
	
?>    
			</div>
		</div>
	</div>
	


</body>
</html>